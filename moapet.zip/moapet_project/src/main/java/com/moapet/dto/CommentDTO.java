// 현재 클래스의 패키지 선언
package com.moapet.dto;

// 작성일시 저장용 Timestamp 클래스 임포트
import java.sql.Timestamp;

/**
 * 댓글 DTO - comment 테이블과 매핑
 */
// 게시글의 댓글 정보를 담는 DTO 클래스
public class CommentDTO {
    private int id;              // 댓글 ID (AUTO_INCREMENT)
    private int boardId;         // 게시글 ID (외래키)
    private String writer;       // 작성자 (member_id)
    private String content;      // 댓글 내용
    private Integer parentId;    // 부모 댓글 ID (대댓글용)
    private Timestamp createdAt; // 작성일시
    
    // 기본 생성자
    public CommentDTO() {}
    
    // 모든 필드를 초기화하는 생성자
    public CommentDTO(int id, int boardId, String writer, String content, 
                      Integer parentId, Timestamp createdAt) {
        this.id = id;
        this.boardId = boardId;
        this.writer = writer;
        this.content = content;
        this.parentId = parentId;
        this.createdAt = createdAt;
    }
    
    // Getter/Setter 메서드들
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getBoardId() { return boardId; }
    public void setBoardId(int boardId) { this.boardId = boardId; }
    
    public String getWriter() { return writer; }
    public void setWriter(String writer) { this.writer = writer; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public Integer getParentId() { return parentId; }
    public void setParentId(Integer parentId) { this.parentId = parentId; }
    
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
    
    @Override
    public String toString() {
        return "CommentDTO{" +
                "id=" + id +
                ", boardId=" + boardId +
                ", writer='" + writer + '\'' +
                ", content='" + content + '\'' +
                ", parentId=" + parentId +
                ", createdAt=" + createdAt +
                '}';
    }
}