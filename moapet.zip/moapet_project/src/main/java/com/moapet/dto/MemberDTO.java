// 현재 클래스의 패키지 선언
package com.moapet.dto;

/**
 * 회원 정보 DTO - member 테이블과 매핑
 */
// 회원 정보를 담는 DTO 클래스 (member 테이블과 매핑됨)
public class MemberDTO {
    private String memberId;      // 회원 식별용 이메일 주소 (로그인 ID)
    private String password;      // 사용자 비밀번호 (보안 위해 암호화 저장)
    private String name;          // 사용자 실명
    private String phone;         // 연락처 전화번호
    private String zipcode;       // 주소 우편번호
    private String address;       // 기본 주소 정보
    private String detailAddress; // 상세 주소 (주소 보완 정보)
    private String status;        // 계정 상태 ('A'=활성 사용자, 'D'=탈퇴 계정)
    
    // 기본 생성자
    public MemberDTO() {}
    
    // 모든 필드를 초기화하는 생성자
    public MemberDTO(String memberId, String password, String name, String phone, 
                     String zipcode, String address, String detailAddress, String status) {
        this.memberId = memberId;
        this.password = password;
        this.name = name;
        this.phone = phone;
        this.zipcode = zipcode;
        this.address = address;
        this.detailAddress = detailAddress;
        this.status = status;
    }
    
    // 각 필드에 대한 Getter/Setter 메서드 정의
    public String getMemberId() { return memberId; }
    public void setMemberId(String memberId) { this.memberId = memberId; }
    
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    
    public String getZipcode() { return zipcode; }
    public void setZipcode(String zipcode) { this.zipcode = zipcode; }
    
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    
    public String getDetailAddress() { return detailAddress; }
    public void setDetailAddress(String detailAddress) { this.detailAddress = detailAddress; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    @Override
    public String toString() {
        return "MemberDTO{" +
                "memberId='" + memberId + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", zipcode='" + zipcode + '\'' +
                ", address='" + address + '\'' +
                ", detailAddress='" + detailAddress + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}