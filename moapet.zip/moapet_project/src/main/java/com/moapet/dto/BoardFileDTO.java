// 현재 클래스의 패키지 선언
package com.moapet.dto;

// Timestamp 클래스 임포트 (업로드 일시에 사용)
import java.sql.Timestamp;

/**
 * 게시판 파일 DTO - board_file 테이블과 매핑
 */
// 게시글 첨부 파일 정보를 담는 DTO 클래스
public class BoardFileDTO {
    private int id;                // 파일 ID (AUTO_INCREMENT)
    private int boardId;           // 게시글 ID (외래키)
    private String originalName;   // 원본 파일명
    private String storedName;     // 저장된 파일명
    private String fileType;       // 파일 타입 (이미지/영상 구분)
    private Timestamp uploadedAt;  // 업로드 일시
    
    // 기본 생성자
    public BoardFileDTO() {}
    
    // 모든 필드를 초기화하는 생성자
    public BoardFileDTO(int id, int boardId, String originalName, String storedName, 
                        String fileType, Timestamp uploadedAt) {
        this.id = id;
        this.boardId = boardId;
        this.originalName = originalName;
        this.storedName = storedName;
        this.fileType = fileType;
        this.uploadedAt = uploadedAt;
    }
    
    // Getter/Setter 메서드들
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getBoardId() { return boardId; }
    public void setBoardId(int boardId) { this.boardId = boardId; }
    
    public String getOriginalName() { return originalName; }
    public void setOriginalName(String originalName) { this.originalName = originalName; }
    
    public String getStoredName() { return storedName; }
    public void setStoredName(String storedName) { this.storedName = storedName; }
    
    public String getFileType() { return fileType; }
    public void setFileType(String fileType) { this.fileType = fileType; }
    
    public Timestamp getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(Timestamp uploadedAt) { this.uploadedAt = uploadedAt; }
    
    @Override
    public String toString() {
        return "BoardFileDTO{" +
                "id=" + id +
                ", boardId=" + boardId +
                ", originalName='" + originalName + '\'' +
                ", storedName='" + storedName + '\'' +
                ", fileType='" + fileType + '\'' +
                ", uploadedAt=" + uploadedAt +
                '}';
    }
}