// 현재 클래스의 패키지 선언
package com.moapet.dto;

/**
 * 장바구니 아이템 DTO - 세션에서 사용
 * (별도 테이블 없이 세션 기반으로 장바구니 관리)
 */
// 장바구니에 담긴 상품 정보를 세션에서 관리하기 위한 DTO 클래스
public class CartItemDTO {
    private int productId;    // 상품 ID
    private String productName; // 상품명 (조회용)
    private int price;        // 상품 가격 (조회용)
    private String imageUrl;  // 상품 이미지 (조회용)
    private int quantity;     // 수량
    private int totalPrice;   // 총 가격 (price * quantity)
    
    // 기본 생성자
    public CartItemDTO() {}
    
    // 필수 필드 생성자 (상품 ID, 수량)
    // 상품 ID와 수량만 초기화하는 생성자
    public CartItemDTO(int productId, int quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }
    
    // 모든 필드 생성자
    public CartItemDTO(int productId, String productName, int price, String imageUrl, int quantity) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.imageUrl = imageUrl;
        this.quantity = quantity;
        this.totalPrice = price * quantity;
    }

    // 각 필드에 대한 Getter/Setter 메서드들
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    
    public int getPrice() { return price; }
    public void setPrice(int price) { 
        this.price = price;
        this.totalPrice = price * quantity; // 총 가격 자동 계산
    }
    
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { 
        this.quantity = quantity;
        this.totalPrice = price * quantity; // 총 가격 자동 계산
    }
    
    public int getTotalPrice() { return totalPrice; }
    public void setTotalPrice(int totalPrice) { this.totalPrice = totalPrice; }
    
    /**
     * 총 가격 계산 메서드
     */
    public void calculateTotalPrice() {
        this.totalPrice = this.price * this.quantity;
    }
    
    @Override
    public String toString() {
        return "CartItemDTO{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", price=" + price +
                ", imageUrl='" + imageUrl + '\'' +
                ", quantity=" + quantity +
                ", totalPrice=" + totalPrice +
                '}';
    }
}