// 현재 클래스의 패키지 선언
package com.moapet.dto;

/**
 * 상품 DTO - product 테이블과 매핑
 */
// 상품 정보를 담는 DTO 클래스 (product 테이블과 매핑)
public class ProductDTO {
    private int id;              // 고유 상품 ID (자동 증가)
    private String name;         // 상품 이름
    private String manufacturer; // 상품 제조사 이름
    private String category;     // 상품 분류명
    private int price;           // 상품 가격 (정수형)
    private int stock;           // 현재 재고 수량
    private String imageUrl;     // 상품 이미지 파일의 경로 또는 URL
    private String description;  // 상품 상세 설명

    // 기본 생성자 (빈 객체 생성 시 사용)
    public ProductDTO() {}
    
    // 모든 필드를 초기화하는 생성자
    public ProductDTO(int id, String name, String manufacturer, String category, 
                      int price, int stock, String imageUrl, String description) {
        this.id = id;
        this.name = name;
        this.manufacturer = manufacturer;
        this.category = category;
        this.price = price;
        this.stock = stock;
        this.imageUrl = imageUrl;
        this.description = description;
    }
    
    // 필드별 Getter/Setter 메서드 정의
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getManufacturer() { return manufacturer; }
    public void setManufacturer(String manufacturer) { this.manufacturer = manufacturer; }
    
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }
    
    public int getPrice() { return price; }
    public void setPrice(int price) { this.price = price; }
    
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    
    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    @Override
    public String toString() {
        return "ProductDTO{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", category='" + category + '\'' +
                ", price=" + price +
                ", stock=" + stock +
                ", imageUrl='" + imageUrl + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}