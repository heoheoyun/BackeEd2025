// 현재 클래스의 패키지 선언
package com.moapet.dto;

// Timestamp 클래스 임포트 (작성일/수정일에 사용)
import java.sql.Timestamp;

/**
 * 게시판 DTO - board 테이블과 매핑
 */
// 게시판 게시글 정보를 담는 DTO 클래스
public class BoardDTO {
    private int id;                // 게시글 ID (AUTO_INCREMENT)
    private String boardType;      // 게시판 타입 (ADOPTION, CARE, FREE)
    private String title;          // 제목
    private String content;        // 내용
    private String region;         // 지역
    private String writer;         // 작성자 (member_id)
    private int hit;              // 조회수
    private Timestamp createdAt;   // 작성일시
    private Timestamp updatedAt;   // 수정일시

    // 기본 생성자
    public BoardDTO() {}
    
    // 모든 필드 생성자
    public BoardDTO(int id, String boardType, String title, String content, 
                    String region, String writer, int hit, Timestamp createdAt, Timestamp updatedAt) {
        this.id = id;
        this.boardType = boardType;
        this.title = title;
        this.content = content;
        this.region = region;
        this.writer = writer;
        this.hit = hit;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    // 각 필드의 Getter/Setter 메서드들
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getBoardType() { return boardType; }
    public void setBoardType(String boardType) { this.boardType = boardType; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    
    public String getRegion() { return region; }
    public void setRegion(String region) { this.region = region; }
    
    public String getWriter() { return writer; }
    public void setWriter(String writer) { this.writer = writer; }
    
    public int getHit() { return hit; }
    public void setHit(int hit) { this.hit = hit; }
    
    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }
    
    public Timestamp getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Timestamp updatedAt) { this.updatedAt = updatedAt; }
    
    @Override
    public String toString() {
        return "BoardDTO{" +
                "id=" + id +
                ", boardType='" + boardType + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", region='" + region + '\'' +
                ", writer='" + writer + '\'' +
                ", hit=" + hit +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }
}
