// 현재 클래스의 패키지 선언
package com.moapet.service;

// 데이터 접근 객체(DAO) 클래스 임포트
import com.moapet.dao.BoardDAO;
import com.moapet.dao.CommentDAO;
// 데이터 전송 객체(DTO) 클래스 임포트
import com.moapet.dto.BoardDTO;
import com.moapet.dto.BoardFileDTO;
import com.moapet.dto.CommentDTO;
// 유틸리티 및 컬렉션 클래스 임포트
import java.util.List;

/**
 * 게시판 관련 비즈니스 로직 처리 클래스
 */
// 게시판 관련 비즈니스 로직을 처리하는 서비스 클래스
public class BoardService {
    private BoardDAO boardDAO;
    private CommentDAO commentDAO;
    private static final int PAGE_SIZE = 10; // 한 페이지에 표시할 게시글 수
    
    // 생성자: DAO 객체들을 초기화
    public BoardService() {
        this.boardDAO = new BoardDAO();
        this.commentDAO = new CommentDAO();
    }
    
    /**
     * 게시글 목록 조회 (페이징)
     */
    // 게시글 목록을 페이징하여 조회
    public List<BoardDTO> getBoardList(String boardType, int page) {
        int offset = (page - 1) * PAGE_SIZE;
        return boardDAO.getBoardList(boardType, offset, PAGE_SIZE);
    }
    
    /**
     * 총 페이지 수 계산
     */
    public int getTotalPages(String boardType) {
        int totalCount = boardDAO.getTotalCount(boardType);
        return (int) Math.ceil((double) totalCount / PAGE_SIZE);
    }
    
    /**
     * 게시글 상세 조회 (조회수 증가 포함)
     */
    // 게시글 상세 정보 조회
    public BoardDTO getBoardDetail(int id, boolean increaseHit) {
        BoardDTO board = boardDAO.getBoardDetail(id);
        
        if (board != null && increaseHit) {
            boardDAO.increaseHit(id);
            board.setHit(board.getHit() + 1); // 메모리상 조회수도 증가
        }
        
        return board;
    }
    
    /**
     * 게시글 작성
     */
    public int writeBoard(BoardDTO board) {
        // 입력값 검증
        if (!validateBoardInfo(board)) {
            return 0;
        }
        
        return boardDAO.insertBoard(board);
    }
    
    /**
     * 게시글 수정
     */
    public boolean updateBoard(BoardDTO board) {
        // 입력값 검증
        if (!validateBoardInfo(board)) {
            return false;
        }
        
        return boardDAO.updateBoard(board);
    }
    
    /**
     * 게시글 삭제
     */
    public boolean deleteBoard(int id, String writer) {
        if (writer == null || writer.trim().isEmpty()) {
            return false;
        }
        
        return boardDAO.deleteBoard(id, writer);
    }
    
    /**
     * 특정 회원이 작성한 게시글 목록 조회
     */
    public List<BoardDTO> getMyBoardList(String writer) {
        if (writer == null || writer.trim().isEmpty()) {
            return null;
        }
        
        return boardDAO.getBoardListByWriter(writer);
    }
    
    /**
     * 게시글 파일 저장
     */
    public boolean saveBoardFile(BoardFileDTO file) {
        if (file == null || file.getBoardId() <= 0 || 
            file.getOriginalName() == null || file.getStoredName() == null) {
            return false;
        }
        
        return boardDAO.insertBoardFile(file);
    }
    
    /**
     * 게시글의 파일 목록 조회
     */
    public List<BoardFileDTO> getBoardFiles(int boardId) {
        return boardDAO.getBoardFiles(boardId);
    }
    
    /**
     * 특정 게시글의 댓글 목록 조회
     */
    public List<CommentDTO> getCommentList(int boardId) {
        return commentDAO.getCommentsByBoardId(boardId);
    }
    
    /**
     * 댓글 작성
     */
    public boolean writeComment(CommentDTO comment) {
        // 입력값 검증
        if (!validateCommentInfo(comment)) {
            return false;
        }
        
        return commentDAO.insertComment(comment);
    }
    
    /**
     * 댓글 수정
     */
    public boolean updateComment(int commentId, String content, String writer) {
        if (content == null || content.trim().isEmpty() || 
            writer == null || writer.trim().isEmpty()) {
            return false;
        }
        
        return commentDAO.updateComment(commentId, content.trim(), writer);
    }
    
    /**
     * 댓글 삭제
     */
    public boolean deleteComment(int commentId, String writer) {
        if (writer == null || writer.trim().isEmpty()) {
            return false;
        }
        
        return commentDAO.deleteComment(commentId, writer);
    }
    
    /**
     * 특정 회원이 작성한 댓글 목록 조회
     */
    public List<CommentDTO> getMyCommentList(String writer) {
        if (writer == null || writer.trim().isEmpty()) {
            return null;
        }
        
        return commentDAO.getCommentsByWriter(writer);
    }
    
    /**
     * 게시글 정보 유효성 검증
     */
    private boolean validateBoardInfo(BoardDTO board) {
        if (board == null) return false;
        
        // 필수 필드 검증
        if (board.getBoardType() == null || board.getBoardType().trim().isEmpty()) return false;
        if (board.getTitle() == null || board.getTitle().trim().isEmpty()) return false;
        if (board.getContent() == null || board.getContent().trim().isEmpty()) return false;
        if (board.getWriter() == null || board.getWriter().trim().isEmpty()) return false;
        
        // 게시판 타입 검증
        String boardType = board.getBoardType().trim();
        if (!boardType.equals("ADOPTION") && !boardType.equals("CARE") && !boardType.equals("FREE")) {
            return false;
        }
        
        return true;
    }
    
    /**
     * 댓글 정보 유효성 검증
     */
    private boolean validateCommentInfo(CommentDTO comment) {
        if (comment == null) return false;
        
        // 필수 필드 검증
        if (comment.getBoardId() <= 0) return false;
        if (comment.getWriter() == null || comment.getWriter().trim().isEmpty()) return false;
        if (comment.getContent() == null || comment.getContent().trim().isEmpty()) return false;
        
        return true;
    }
}