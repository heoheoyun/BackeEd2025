// 현재 클래스의 패키지 선언
package com.moapet.service;

// DAO 클래스 임포트 (데이터 접근)
import com.moapet.dao.MemberDAO;
// DTO 클래스 임포트 (데이터 전달용)
import com.moapet.dto.MemberDTO;
// 비밀번호 암호화를 위한 보안 관련 클래스 임포트
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * 회원 관련 비즈니스 로직 처리 클래스
 */
// 회원 관련 로직을 처리하는 서비스 클래스
public class MemberService {
    private MemberDAO memberDAO;
    
    // 생성자: MemberDAO 객체 초기화
    public MemberService() {
        this.memberDAO = new MemberDAO();
    }
    
    /**
     * 회원 로그인 처리
     */
    // 로그인 처리: 암호화된 비밀번호와 ID 확인
    public MemberDTO login(String memberId, String password) {
        if (memberId == null || password == null || 
            memberId.trim().isEmpty() || password.trim().isEmpty()) {
            return null;
        }
        
        // 비밀번호 암호화
        String encryptedPassword = encryptPassword(password);
        
        return memberDAO.login(memberId.trim(), encryptedPassword);
    }
    
    /**
     * 회원가입 처리
     */
    public boolean register(MemberDTO member) {
        // 입력값 검증
        if (!validateMemberInfo(member)) {
            return false;
        }
        
        // 아이디 중복 확인
        if (memberDAO.checkDuplicateId(member.getMemberId())) {
            return false;
        }
        
        // 비밀번호 암호화
        member.setPassword(encryptPassword(member.getPassword()));
        
        return memberDAO.register(member);
    }
    
    /**
     * 아이디 중복 확인
     */
    public boolean checkDuplicateId(String memberId) {
        if (memberId == null || memberId.trim().isEmpty()) {
            return true; // 빈 값은 중복으로 처리
        }
        
        return memberDAO.checkDuplicateId(memberId.trim());
    }
    
    /**
     * 회원 정보 조회
     */
    public MemberDTO getMemberInfo(String memberId) {
        if (memberId == null || memberId.trim().isEmpty()) {
            return null;
        }
        
        return memberDAO.getMemberById(memberId.trim());
    }
    
    /**
     * 회원 정보 유효성 검증
     */
    private boolean validateMemberInfo(MemberDTO member) {
        if (member == null) return false;
        
        // 필수 필드 검증
        if (member.getMemberId() == null || member.getMemberId().trim().isEmpty()) return false;
        if (member.getPassword() == null || member.getPassword().trim().isEmpty()) return false;
        if (member.getName() == null || member.getName().trim().isEmpty()) return false;
        
        // 이메일 형식 검증 (간단한 검증)
        String email = member.getMemberId().trim();
        if (!email.contains("@") || !email.contains(".")) return false;
        
        return true;
    }
    
    /**
     * 비밀번호 암호화 (SHA-256)
     */
    private String encryptPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = md.digest(password.getBytes());
            
            StringBuilder sb = new StringBuilder();
            for (byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return password; // 암호화 실패시 원본 반환 (임시)
        }
    }
}