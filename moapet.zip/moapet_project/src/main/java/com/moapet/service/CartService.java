// 현재 클래스의 패키지 선언
package com.moapet.service;

// DTO 클래스 임포트
import com.moapet.dto.CartItemDTO;
import com.moapet.dto.ProductDTO;
// 세션 및 컬렉션 관련 클래스 임포트
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * 장바구니 관련 비즈니스 로직 처리 클래스 (세션 기반)
 */
// 장바구니 관련 비즈니스 로직을 담당하는 서비스 클래스 (세션 기반)
public class CartService {
    private ProductService productService;
    private static final String CART_SESSION_KEY = "cart"; // 세션에 저장될 장바구니 키
    
    // 생성자: 상품 서비스 초기화
    public CartService() {
        this.productService = new ProductService();
    }
    
    /**
     * 세션에서 장바구니 Map 가져오기
     * Key: productId(Integer), Value: quantity(Integer)
     */
    @SuppressWarnings("unchecked")
    private Map<Integer, Integer> getCartFromSession(HttpSession session) {
        Map<Integer, Integer> cart = (Map<Integer, Integer>) session.getAttribute(CART_SESSION_KEY);
        if (cart == null) {
            cart = new HashMap<>();
            session.setAttribute(CART_SESSION_KEY, cart);
        }
        return cart;
    }
    
    /**
     * 장바구니에 상품 추가
     */
    public boolean addToCart(HttpSession session, int productId, int quantity) {
        if (productId <= 0 || quantity <= 0) {
            return false;
        }
        
        // 재고 확인
        if (!productService.checkStock(productId, quantity)) {
            return false;
        }
        
        Map<Integer, Integer> cart = getCartFromSession(session);
        
        // 이미 장바구니에 있는 상품이면 수량 추가
        if (cart.containsKey(productId)) {
            int currentQuantity = cart.get(productId);
            int newQuantity = currentQuantity + quantity;
            
            // 재고 확인 (기존 수량 + 추가 수량)
            if (!productService.checkStock(productId, newQuantity)) {
                return false;
            }
            
            cart.put(productId, newQuantity);
        } else {
            cart.put(productId, quantity);
        }
        
        return true;
    }
    
    /**
     * 장바구니 상품 수량 변경
     */
    public boolean updateCartItemQuantity(HttpSession session, int productId, int quantity) {
        if (productId <= 0 || quantity <= 0) {
            return false;
        }
        
        // 재고 확인
        if (!productService.checkStock(productId, quantity)) {
            return false;
        }
        
        Map<Integer, Integer> cart = getCartFromSession(session);
        
        if (cart.containsKey(productId)) {
            cart.put(productId, quantity);
            return true;
        }
        
        return false;
    }
    
    /**
     * 장바구니에서 상품 삭제
     */
    public boolean removeFromCart(HttpSession session, int productId) {
        if (productId <= 0) {
            return false;
        }
        
        Map<Integer, Integer> cart = getCartFromSession(session);
        
        if (cart.containsKey(productId)) {
            cart.remove(productId);
            return true;
        }
        
        return false;
    }
    
    /**
     * 장바구니 전체 비우기
     */
    // 장바구니 비우기
    public void clearCart(HttpSession session) {
        Map<Integer, Integer> cart = getCartFromSession(session);
        cart.clear();
    }
    
    /**
     * 장바구니 목록 조회 (상품 정보 포함)
     */
    public List<CartItemDTO> getCartList(HttpSession session) {
        Map<Integer, Integer> cart = getCartFromSession(session);
        
        if (cart.isEmpty()) {
            return new ArrayList<>();
        }
        
        List<CartItemDTO> cartItems = new ArrayList<>();
        List<Integer> productIds = new ArrayList<>(cart.keySet());
        
        // 상품 정보 조회
        List<ProductDTO> products = productService.getProductsByIds(productIds);
        
        if (products != null) {
            for (ProductDTO product : products) {
                int quantity = cart.get(product.getId());
                
                CartItemDTO cartItem = new CartItemDTO();
                cartItem.setProductId(product.getId());
                cartItem.setProductName(product.getName());
                cartItem.setPrice(product.getPrice());
                cartItem.setImageUrl(product.getImageUrl());
                cartItem.setQuantity(quantity);
                cartItem.calculateTotalPrice();
                
                cartItems.add(cartItem);
            }
        }
        
        // 상품 ID 순으로 정렬
        cartItems.sort((item1, item2) -> Integer.compare(item1.getProductId(), item2.getProductId()));
        
        return cartItems;
    }
    
    /**
     * 장바구니 총 상품 개수 조회
     */
    public int getCartItemCount(HttpSession session) {
        Map<Integer, Integer> cart = getCartFromSession(session);
        
        int totalCount = 0;
        for (int quantity : cart.values()) {
            totalCount += quantity;
        }
        
        return totalCount;
    }
    
    /**
     * 장바구니 총 금액 계산
     */
    public int getCartTotalPrice(HttpSession session) {
        List<CartItemDTO> cartItems = getCartList(session);
        
        int totalPrice = 0;
        for (CartItemDTO item : cartItems) {
            totalPrice += item.getTotalPrice();
        }
        
        return totalPrice;
    }
    
    /**
     * 특정 상품이 장바구니에 있는지 확인
     */
    public boolean isProductInCart(HttpSession session, int productId) {
        if (productId <= 0) {
            return false;
        }
        
        Map<Integer, Integer> cart = getCartFromSession(session);
        return cart.containsKey(productId);
    }
    
    /**
     * 장바구니에서 특정 상품의 수량 조회
     */
    public int getProductQuantityInCart(HttpSession session, int productId) {
        if (productId <= 0) {
            return 0;
        }
        
        Map<Integer, Integer> cart = getCartFromSession(session);
        return cart.getOrDefault(productId, 0);
    }
    
    /**
     * 장바구니가 비어있는지 확인
     */
    public boolean isCartEmpty(HttpSession session) {
        Map<Integer, Integer> cart = getCartFromSession(session);
        return cart.isEmpty();
    }
    
    /**
     * 장바구니 요약 정보 조회
     */
    public Map<String, Object> getCartSummary(HttpSession session) {
        Map<String, Object> summary = new HashMap<>();
        
        int itemCount = getCartItemCount(session);
        int totalPrice = getCartTotalPrice(session);
        boolean isEmpty = isCartEmpty(session);
        
        summary.put("itemCount", itemCount);
        summary.put("totalPrice", totalPrice);
        summary.put("isEmpty", isEmpty);
        
        return summary;
    }
}