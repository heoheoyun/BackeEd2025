// 현재 클래스의 패키지 선언
package com.moapet.service;

// DAO 클래스 임포트 (상품 데이터 처리)
import com.moapet.dao.ProductDAO;
// DTO 클래스 임포트 (상품 데이터 전달)
import com.moapet.dto.ProductDTO;
// 리스트 등의 유틸리티 클래스 임포트
import java.util.List;

/**
 * 상품 관련 비즈니스 로직 처리 클래스
 */
// 상품 관련 비즈니스 로직을 처리하는 서비스 클래스
public class ProductService {
    private ProductDAO productDAO;
    private static final int PAGE_SIZE = 12; // 한 페이지에 표시할 상품 개수
    
    // 생성자: DAO 객체 초기화
    public ProductService() {
        this.productDAO = new ProductDAO();
    }
    
    /**
     * 상품 목록 조회 (페이징)
     */
    // 상품 목록을 카테고리와 페이징 기준에 따라 조회
    public List<ProductDTO> getProductList(String category, int page) {
        int offset = (page - 1) * PAGE_SIZE;
        return productDAO.getProductList(category, offset, PAGE_SIZE);
    }
    
    /**
     * 총 페이지 수 계산
     */
    public int getTotalPages(String category) {
        int totalCount = productDAO.getTotalProductCount(category);
        return (int) Math.ceil((double) totalCount / PAGE_SIZE);
    }
    
    /**
     * 상품 상세 조회
     */
    // 특정 상품 ID에 해당하는 상품 상세 정보 조회
    public ProductDTO getProductDetail(int productId) {
        if (productId <= 0) {
            return null;
        }
        
        return productDAO.getProductById(productId);
    }
    
    /**
     * 상품 검색
     */
    public List<ProductDTO> searchProducts(String keyword, int page) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getProductList(null, page);
        }
        
        int offset = (page - 1) * PAGE_SIZE;
        return productDAO.searchProducts(keyword.trim(), offset, PAGE_SIZE);
    }
    
    /**
     * 검색 결과 총 페이지 수 계산
     */
    public int getSearchTotalPages(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getTotalPages(null);
        }
        
        int totalCount = productDAO.getSearchResultCount(keyword.trim());
        return (int) Math.ceil((double) totalCount / PAGE_SIZE);
    }
    
    /**
     * 카테고리 목록 조회
     */
    public List<String> getCategories() {
        return productDAO.getCategories();
    }
    
    /**
     * 여러 상품 정보 조회 (장바구니용)
     */
    public List<ProductDTO> getProductsByIds(List<Integer> productIds) {
        if (productIds == null || productIds.isEmpty()) {
            return null;
        }
        
        return productDAO.getProductsByIds(productIds);
    }
    
    /**
     * 상품 재고 확인
     */
    public boolean checkStock(int productId, int quantity) {
        ProductDTO product = getProductDetail(productId);
        if (product == null) {
            return false;
        }
        
        return product.getStock() >= quantity;
    }
}