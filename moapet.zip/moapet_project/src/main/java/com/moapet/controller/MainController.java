// ========== MainController.java ==========
// 현재 클래스가 속한 패키지
package com.moapet.controller;

// 외부 클래스 및 라이브러리 임포트
import com.moapet.service.*;
import com.moapet.dto.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

/**
 * 모든 *.do 요청을 처리하는 메인 컨트롤러
 */
// 모든 *.do 요청을 이 서블릿으로 매핑
@WebServlet("*.do")
// 파일 업로드를 위한 설정
@MultipartConfig(
    // 메모리 저장 최대 크기: 2MB
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    // 업로드 개별 파일 최대 크기: 10MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    // 전체 요청 최대 크기: 50MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
public class MainController extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Service 객체들
    private MemberService memberService;
    private BoardService boardService;
    private ProductService productService;
    private CartService cartService;
    
    @Override
    // 컨트롤러 초기화 시 서비스 객체 생성
    public void init() throws ServletException {
        memberService = new MemberService();
        boardService = new BoardService();
        productService = new ProductService();
        cartService = new CartService();
    }
    
    @Override
    // 클라이언트 요청 처리 (GET/POST)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
    // 공통 요청 처리 메서드
        processRequest(request, response);
    }
    
    @Override
    // 클라이언트 요청 처리 (GET/POST)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
    // 공통 요청 처리 메서드
        processRequest(request, response);
    }
    
    /**
     * 모든 요청을 처리하는 메인 메서드
     */
    // 공통 요청 처리 메서드
    private void processRequest(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        
        String uri = request.getRequestURI();
        String action = uri.substring(uri.lastIndexOf("/") + 1);
        
        // 디버깅 로그
        System.out.println("=== 요청 받음: " + uri);
        System.out.println("=== 액션: " + action);
        
        String viewPage = "";
        
        try {
            switch (action) {
                // ===== 회원 관련 =====
                case "login.do":
                    viewPage = handleLogin(request, response);
                    break;
                case "loginForm.do":
                    viewPage = "/WEB-INF/views/member/login.jsp";
                    break;
                case "logout.do":
                    viewPage = handleLogout(request, response);
                    break;
                case "registerForm.do":
                    viewPage = "/WEB-INF/views/member/register.jsp";
                    break;
                case "register.do":
                    viewPage = handleRegister(request, response);
                    break;
                case "checkId.do":
                    viewPage = handleCheckId(request, response);
                    break;
                case "mypage.do":
                    viewPage = handleMypage(request, response);
                    break;
                
                // ===== 게시판 관련 =====
                case "boardList.do":
                    viewPage = handleBoardList(request, response);
                    break;
                case "boardDetail.do":
                    viewPage = handleBoardDetail(request, response);
                    break;
                case "boardWriteForm.do":
                    viewPage = handleBoardWriteForm(request, response);
                    break;
                case "boardWrite.do":
                    viewPage = handleBoardWrite(request, response);
                    break;
                case "boardEditForm.do":
                    viewPage = handleBoardEditForm(request, response);
                    break;
                case "boardEdit.do":
                    viewPage = handleBoardEdit(request, response);
                    break;
                case "boardDelete.do":
                    viewPage = handleBoardDelete(request, response);
                    break;
                
                // ===== 댓글 관련 =====
                case "commentWrite.do":
                    viewPage = handleCommentWrite(request, response);
                    break;
                case "commentEdit.do":
                    viewPage = handleCommentEdit(request, response);
                    break;
                case "commentDelete.do":
                    viewPage = handleCommentDelete(request, response);
                    break;
                
                // ===== 상품 관련 =====
                case "productList.do":
                    viewPage = handleProductList(request, response);
                    break;
                case "productDetail.do":
                    viewPage = handleProductDetail(request, response);
                    break;
                case "productSearch.do":
                    viewPage = handleProductSearch(request, response);
                    break;
                
                // ===== 장바구니 관련 =====
                case "cartList.do":
                    viewPage = handleCartList(request, response);
                    break;
                case "cartAdd.do":
                    viewPage = handleCartAdd(request, response);
                    break;
                case "cartUpdate.do":
                    viewPage = handleCartUpdate(request, response);
                    break;
                case "cartRemove.do":
                    viewPage = handleCartRemove(request, response);
                    break;
                case "cartClear.do":
                    viewPage = handleCartClear(request, response);
                    break;
                case "cartCount.do":
                    viewPage = handleCartCount(request, response);
                    break;
                
                // ===== 테스트용 =====
                case "test.do":
                    response.getWriter().write("Controller 작동 중! 현재 시간: " + new java.util.Date());
                    return;
                
                default:
                    System.out.println("=== 매칭되지 않은 액션, index.jsp로 이동");
                    viewPage = "/index.jsp";
                    break;
            }
            
            System.out.println("=== viewPage: " + viewPage);
            
            if (viewPage != null && !viewPage.isEmpty()) {
                if (viewPage.startsWith("redirect:")) {
                    String redirectUrl = viewPage.substring(9);
                    System.out.println("=== 리다이렉트: " + redirectUrl);
                    response.sendRedirect(redirectUrl);
                } else {
                    System.out.println("=== 포워드: " + viewPage);
                    request.getRequestDispatcher(viewPage).forward(request, response);
                }
            }
            
        } catch (Exception e) {
            System.out.println("=== 오류 발생: " + e.getMessage());
            e.printStackTrace();
            request.setAttribute("errorMessage", "처리 중 오류가 발생했습니다.");
            request.getRequestDispatcher("/WEB-INF/views/common/error.jsp").forward(request, response);
        }
    }
    
    // ===== 회원 관련 메서드 =====
    
    /**
     * 로그인 처리
     */
    private String handleLogin(HttpServletRequest request, HttpServletResponse response) {
        String memberId = request.getParameter("memberId");
        String password = request.getParameter("password");
        
        MemberDTO member = memberService.login(memberId, password);
        
        if (member != null) {
            HttpSession session = request.getSession();
            session.setAttribute("loginMember", member);
            return "redirect:index.jsp";
        } else {
            request.setAttribute("errorMessage", "아이디 또는 비밀번호가 올바르지 않습니다.");
            return "/WEB-INF/views/member/login.jsp";
        }
    }
    
    /**
     * 로그아웃 처리
     */
    private String handleLogout(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        session.invalidate();
        return "redirect:index.jsp";
    }
    
    /**
     * 회원가입 처리
     */
    private String handleRegister(HttpServletRequest request, HttpServletResponse response) {
        String memberId = request.getParameter("memberId");
        String password = request.getParameter("password");
        String name = request.getParameter("name");
        String phone = request.getParameter("phone");
        String zipcode = request.getParameter("zipcode");
        String address = request.getParameter("address");
        String detailAddress = request.getParameter("detailAddress");
        
        MemberDTO member = new MemberDTO();
        member.setMemberId(memberId);
        member.setPassword(password);
        member.setName(name);
        member.setPhone(phone);
        member.setZipcode(zipcode);
        member.setAddress(address);
        member.setDetailAddress(detailAddress);
        
        boolean result = memberService.register(member);
        
        if (result) {
            request.setAttribute("successMessage", "회원가입이 완료되었습니다.");
            return "/WEB-INF/views/member/login.jsp";
        } else {
            request.setAttribute("errorMessage", "회원가입에 실패했습니다.");
            request.setAttribute("member", member);
            return "/WEB-INF/views/member/register.jsp";
        }
    }
    
    /**
     * 아이디 중복 확인
     */
    private String handleCheckId(HttpServletRequest request, HttpServletResponse response) {
        String memberId = request.getParameter("memberId");
        boolean isDuplicate = memberService.checkDuplicateId(memberId);
        
        request.setAttribute("memberId", memberId);
        request.setAttribute("isDuplicate", isDuplicate);
        
        return "/WEB-INF/views/member/registerCheck.jsp";
    }
    
    /**
     * 마이페이지
     */
    private String handleMypage(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        // 내가 쓴 글 목록
        List<BoardDTO> myBoards = boardService.getMyBoardList(loginMember.getMemberId());
        request.setAttribute("myBoards", myBoards);
        
        // 내가 쓴 댓글 목록
        List<CommentDTO> myComments = boardService.getMyCommentList(loginMember.getMemberId());
        request.setAttribute("myComments", myComments);
        
        return "/WEB-INF/views/member/mypage.jsp";
    }
    
    // ===== 게시판 관련 메서드 =====
    
    /**
     * 게시글 목록
     */
    private String handleBoardList(HttpServletRequest request, HttpServletResponse response) {
        String boardType = request.getParameter("boardType");
        String pageStr = request.getParameter("page");
        
        int page = 1;
        if (pageStr != null && !pageStr.isEmpty()) {
            try {
                page = Integer.parseInt(pageStr);
            } catch (NumberFormatException e) {
                page = 1;
            }
        }
        
        List<BoardDTO> boardList = boardService.getBoardList(boardType, page);
        int totalPages = boardService.getTotalPages(boardType);
        
        request.setAttribute("boardList", boardList);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("boardType", boardType);
        
        return "/WEB-INF/views/board/boardList.jsp";
    }
    
    /**
     * 게시글 상세
     */
    private String handleBoardDetail(HttpServletRequest request, HttpServletResponse response) {
        String idStr = request.getParameter("id");
        
        if (idStr == null || idStr.isEmpty()) {
            return "redirect:boardList.do";
        }
        
        try {
            int id = Integer.parseInt(idStr);
            BoardDTO board = boardService.getBoardDetail(id, true); // 조회수 증가
            
            if (board == null) {
                request.setAttribute("errorMessage", "존재하지 않는 게시글입니다.");
                return "/WEB-INF/views/board/boardList.jsp";
            }
            
            // 댓글 목록 조회
            List<CommentDTO> comments = boardService.getCommentList(id);
            
            // 파일 목록 조회
            List<BoardFileDTO> files = boardService.getBoardFiles(id);
            
            request.setAttribute("board", board);
            request.setAttribute("comments", comments);
            request.setAttribute("files", files);
            
            return "/WEB-INF/views/board/boardDetail.jsp";
            
        } catch (NumberFormatException e) {
            return "redirect:boardList.do";
        }
    }
    
    /**
     * 게시글 작성 폼
     */
    private String handleBoardWriteForm(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String boardType = request.getParameter("boardType");
        request.setAttribute("boardType", boardType);
        
        return "/WEB-INF/views/board/boardWrite.jsp";
    }
    
    /**
     * 게시글 작성 처리
     */
    private String handleBoardWrite(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String boardType = request.getParameter("boardType");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String region = request.getParameter("region");
        
        BoardDTO board = new BoardDTO();
        board.setBoardType(boardType);
        board.setTitle(title);
        board.setContent(content);
        board.setRegion(region);
        board.setWriter(loginMember.getMemberId());
        
        int boardId = boardService.writeBoard(board);
        
        if (boardId > 0) {
            // 파일 업로드 처리
            handleFileUpload(request, boardId);
            return "redirect:boardDetail.do?id=" + boardId;
        } else {
            request.setAttribute("errorMessage", "게시글 작성에 실패했습니다.");
            request.setAttribute("board", board);
            return "/WEB-INF/views/board/boardWrite.jsp";
        }
    }
    
    /**
     * 게시글 수정 폼
     */
    private String handleBoardEditForm(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String idStr = request.getParameter("id");
        if (idStr == null || idStr.isEmpty()) {
            return "redirect:boardList.do";
        }
        
        try {
            int id = Integer.parseInt(idStr);
            BoardDTO board = boardService.getBoardDetail(id, false);
            
            if (board == null || !board.getWriter().equals(loginMember.getMemberId())) {
                request.setAttribute("errorMessage", "수정 권한이 없습니다.");
                return "redirect:boardList.do";
            }
            
            request.setAttribute("board", board);
            return "/WEB-INF/views/board/boardWrite.jsp";
            
        } catch (NumberFormatException e) {
            return "redirect:boardList.do";
        }
    }
    
    /**
     * 게시글 수정 처리
     */
    private String handleBoardEdit(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String idStr = request.getParameter("id");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String region = request.getParameter("region");
        
        try {
            int id = Integer.parseInt(idStr);
            
            BoardDTO board = new BoardDTO();
            board.setId(id);
            board.setTitle(title);
            board.setContent(content);
            board.setRegion(region);
            board.setWriter(loginMember.getMemberId());
            
            boolean result = boardService.updateBoard(board);
            
            if (result) {
                return "redirect:boardDetail.do?id=" + id;
            } else {
                request.setAttribute("errorMessage", "게시글 수정에 실패했습니다.");
                request.setAttribute("board", board);
                return "/WEB-INF/views/board/boardWrite.jsp";
            }
            
        } catch (NumberFormatException e) {
            return "redirect:boardList.do";
        }
    }
    
    /**
     * 게시글 삭제 처리
     */
    private String handleBoardDelete(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String idStr = request.getParameter("id");
        if (idStr == null || idStr.isEmpty()) {
            return "redirect:boardList.do";
        }
        
        try {
            int id = Integer.parseInt(idStr);
            boolean result = boardService.deleteBoard(id, loginMember.getMemberId());
            
            if (result) {
                return "redirect:boardList.do";
            } else {
                request.setAttribute("errorMessage", "게시글 삭제에 실패했습니다.");
                return "redirect:boardDetail.do?id=" + id;
            }
            
        } catch (NumberFormatException e) {
            return "redirect:boardList.do";
        }
    }
    
    // ===== 댓글 관련 메서드 =====
    
    /**
     * 댓글 작성 처리
     */
    private String handleCommentWrite(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String boardIdStr = request.getParameter("boardId");
        String content = request.getParameter("content");
        String parentIdStr = request.getParameter("parentId");
        
        try {
            int boardId = Integer.parseInt(boardIdStr);
            
            CommentDTO comment = new CommentDTO();
            comment.setBoardId(boardId);
            comment.setWriter(loginMember.getMemberId());
            comment.setContent(content);
            
            if (parentIdStr != null && !parentIdStr.isEmpty()) {
                comment.setParentId(Integer.parseInt(parentIdStr));
            }
            
            boolean result = boardService.writeComment(comment);
            
            if (!result) {
                request.setAttribute("errorMessage", "댓글 작성에 실패했습니다.");
            }
            
            return "redirect:boardDetail.do?id=" + boardId;
            
        } catch (NumberFormatException e) {
            return "redirect:boardList.do";
        }
    }
    
    /**
     * 댓글 수정 처리
     */
    private String handleCommentEdit(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String commentIdStr = request.getParameter("commentId");
        String boardIdStr = request.getParameter("boardId");
        String content = request.getParameter("content");
        
        try {
            int commentId = Integer.parseInt(commentIdStr);
            int boardId = Integer.parseInt(boardIdStr);
            
            boolean result = boardService.updateComment(commentId, content, loginMember.getMemberId());
            
            if (!result) {
                request.setAttribute("errorMessage", "댓글 수정에 실패했습니다.");
            }
            
            return "redirect:boardDetail.do?id=" + boardId;
            
        } catch (NumberFormatException e) {
            return "redirect:boardList.do";
        }
    }
    
    /**
     * 댓글 삭제 처리
     */
    private String handleCommentDelete(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String commentIdStr = request.getParameter("commentId");
        String boardIdStr = request.getParameter("boardId");
        
        try {
            int commentId = Integer.parseInt(commentIdStr);
            int boardId = Integer.parseInt(boardIdStr);
            
            boolean result = boardService.deleteComment(commentId, loginMember.getMemberId());
            
            if (!result) {
                request.setAttribute("errorMessage", "댓글 삭제에 실패했습니다.");
            }
            
            return "redirect:boardDetail.do?id=" + boardId;
            
        } catch (NumberFormatException e) {
            return "redirect:boardList.do";
        }
    }
    
    // ===== 상품 관련 메서드 =====
    
    /**
     * 상품 목록
     */
    private String handleProductList(HttpServletRequest request, HttpServletResponse response) {
        String category = request.getParameter("category");
        String pageStr = request.getParameter("page");
        
        int page = 1;
        if (pageStr != null && !pageStr.isEmpty()) {
            try {
                page = Integer.parseInt(pageStr);
            } catch (NumberFormatException e) {
                page = 1;
            }
        }
        
        List<ProductDTO> productList = productService.getProductList(category, page);
        int totalPages = productService.getTotalPages(category);
        List<String> categories = productService.getCategories();
        
        request.setAttribute("productList", productList);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("category", category);
        request.setAttribute("categories", categories);
        
        return "/WEB-INF/views/product/productList.jsp";
    }
    
    /**
     * 상품 상세
     */
    private String handleProductDetail(HttpServletRequest request, HttpServletResponse response) {
        String idStr = request.getParameter("id");
        
        if (idStr == null || idStr.isEmpty()) {
            return "redirect:productList.do";
        }
        
        try {
            int id = Integer.parseInt(idStr);
            ProductDTO product = productService.getProductDetail(id);
            
            if (product == null) {
                request.setAttribute("errorMessage", "존재하지 않는 상품입니다.");
                return "redirect:productList.do";
            }
            
            request.setAttribute("product", product);
            return "/WEB-INF/views/product/productDetail.jsp";
            
        } catch (NumberFormatException e) {
            return "redirect:productList.do";
        }
    }
    
    /**
     * 상품 검색
     */
    private String handleProductSearch(HttpServletRequest request, HttpServletResponse response) {
        String keyword = request.getParameter("keyword");
        String pageStr = request.getParameter("page");
        
        int page = 1;
        if (pageStr != null && !pageStr.isEmpty()) {
            try {
                page = Integer.parseInt(pageStr);
            } catch (NumberFormatException e) {
                page = 1;
            }
        }
        
        List<ProductDTO> productList = productService.searchProducts(keyword, page);
        int totalPages = productService.getSearchTotalPages(keyword);
        List<String> categories = productService.getCategories();
        
        request.setAttribute("productList", productList);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("keyword", keyword);
        request.setAttribute("categories", categories);
        
        return "/WEB-INF/views/product/productList.jsp";
    }
    
    // ===== 장바구니 관련 메서드 =====
    
    /**
     * 장바구니 목록
     */
    private String handleCartList(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        List<CartItemDTO> cartList = cartService.getCartList(session);
        Map<String, Object> cartSummary = cartService.getCartSummary(session);
        
        request.setAttribute("cartList", cartList);
        request.setAttribute("cartSummary", cartSummary);
        
        return "/WEB-INF/views/cart/cartList.jsp";
    }
    
    /**
     * 장바구니 상품 추가
     */
    private String handleCartAdd(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String productIdStr = request.getParameter("productId");
        String quantityStr = request.getParameter("quantity");
        
        try {
            int productId = Integer.parseInt(productIdStr);
            int quantity = Integer.parseInt(quantityStr);
            
            boolean result = cartService.addToCart(session, productId, quantity);
            
            if (result) {
                request.setAttribute("successMessage", "장바구니에 상품이 추가되었습니다.");
            } else {
                request.setAttribute("errorMessage", "장바구니 추가에 실패했습니다. (재고 부족)");
            }
            
            return "redirect:productDetail.do?id=" + productId;
            
        } catch (NumberFormatException e) {
            return "redirect:productList.do";
        }
    }
    
    /**
     * 장바구니 수량 변경
     */
    private String handleCartUpdate(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String productIdStr = request.getParameter("productId");
        String quantityStr = request.getParameter("quantity");
        
        try {
            int productId = Integer.parseInt(productIdStr);
            int quantity = Integer.parseInt(quantityStr);
            
            boolean result = cartService.updateCartItemQuantity(session, productId, quantity);
            
            if (!result) {
                request.setAttribute("errorMessage", "수량 변경에 실패했습니다. (재고 부족)");
            }
            
            return "redirect:cartList.do";
            
        } catch (NumberFormatException e) {
            return "redirect:cartList.do";
        }
    }
    
    /**
     * 장바구니 상품 삭제
     */
    private String handleCartRemove(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        String productIdStr = request.getParameter("productId");
        
        try {
            int productId = Integer.parseInt(productIdStr);
            cartService.removeFromCart(session, productId);
            
            return "redirect:cartList.do";
            
        } catch (NumberFormatException e) {
            return "redirect:cartList.do";
        }
    }
    
    /**
     * 장바구니 전체 비우기
     */
    private String handleCartClear(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            return "redirect:loginForm.do";
        }
        
        cartService.clearCart(session);
        return "redirect:cartList.do";
    }
    
    /**
     * 장바구니 개수 확인 (별도 페이지)
     */
    private String handleCartCount(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        MemberDTO loginMember = (MemberDTO) session.getAttribute("loginMember");
        
        if (loginMember == null) {
            request.setAttribute("cartCount", 0);
        } else {
            int cartCount = cartService.getCartItemCount(session);
            request.setAttribute("cartCount", cartCount);
        }
        
        return "/WEB-INF/views/cart/cartCount.jsp";
    }
    
    // ===== 유틸리티 메서드 =====
    
    /**
     * 파일 업로드 처리
     */
    private void handleFileUpload(HttpServletRequest request, int boardId) 
            throws ServletException, IOException {
        
        Collection<Part> parts = request.getParts();
        String uploadPath = getServletContext().getRealPath("/UPLOAD");
        
        // UPLOAD 디렉토리가 없으면 생성
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        
        for (Part part : parts) {
            String fileName = getFileName(part);
            
            if (fileName != null && !fileName.isEmpty()) {
                // 파일명 중복 방지를 위해 현재 시간 추가
                String storedName = System.currentTimeMillis() + "_" + fileName;
                String filePath = uploadPath + File.separator + storedName;
                
                // 파일 저장
                part.write(filePath);
                
                // 파일 정보 DB 저장
                BoardFileDTO fileDto = new BoardFileDTO();
                fileDto.setBoardId(boardId);
                fileDto.setOriginalName(fileName);
                fileDto.setStoredName(storedName);
                fileDto.setFileType(getFileType(fileName));
                
                boardService.saveBoardFile(fileDto);
            }
        }
    }
    
    /**
     * Part에서 파일명 추출
     */
    private String getFileName(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] tokens = contentDisposition.split(";");
        
        for (String token : tokens) {
            if (token.trim().startsWith("filename")) {
                return token.substring(token.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return null;
    }
    
    /**
     * 파일 확장자로 타입 구분
     */
    private String getFileType(String fileName) {
        String extension = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
        
        if (extension.matches("jpg|jpeg|png|gif|bmp")) {
            return "image";
        } else if (extension.matches("mp4|avi|mov|wmv")) {
            return "video";
        } else {
            return "file";
        }
    }
}