// DB 연결을 위한 유틸리티 클래스
// ========== DBUtil.java ==========
// 현재 클래스의 패키지 선언
package com.moapet.util;

// JDBC 연결 및 예외 처리를 위한 클래스 임포트
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * MariaDB 연결 전용 유틸리티 클래스
 */
// MariaDB 연결 처리를 위한 정적 유틸리티 클래스
public class DBUtil {
    private static final String DRIVER = "org.mariadb.jdbc.Driver"; // JDBC 드라이버 클래스명
    private static final String URL = "jdbc:mariadb://127.0.0.1:3307/moapet"; // DB 주소
    private static final String USERNAME = "moapet_admin"; // DB 사용자 ID
    private static final String PASSWORD = "1111"; // DB 비밀번호
    
    // 클래스 초기화 시 드라이버 로딩 시도
    static {
        try {
            // 드라이버 클래스 로딩 시도
            Class.forName(DRIVER);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 데이터베이스 연결 반환
     */
    // DB 연결 객체를 반환하는 정적 메서드
    public static Connection getConnection() throws SQLException {
        // DB 연결 객체 생성 후 반환
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
    
    /**
     * 연결 종료
     */
    public static void close(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}