// 현재 클래스의 패키지 선언
package com.moapet.dao;

// DTO, DB 유틸리티, JDBC 및 리스트 관련 클래스 임포트
import com.moapet.dto.ProductDTO;
import com.moapet.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 상품 관련 데이터베이스 접근 클래스
 */
// 상품 관련 데이터 처리를 담당하는 DAO 클래스
public class ProductDAO {
    
    /**
     * 상품 목록 조회 (전체 또는 카테고리별)
     */
    // 전체 또는 특정 카테고리의 상품 목록을 페이징하여 조회
    public List<ProductDTO> getProductList(String category, int offset, int limit) {
        // 결과를 저장할 리스트 초기화
        List<ProductDTO> products = new ArrayList<>();
        // 기본 SQL 쿼리 작성
        String sql = "SELECT * FROM product";
        
        // 카테고리가 지정된 경우, 조건을 추가
        if (category != null && !category.isEmpty()) {
            sql += " WHERE category = ?";
        }
        sql += " ORDER BY id DESC LIMIT ?, ?";
        
        // DB 연결 및 SQL 실행을 위한 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            int paramIndex = 1;
        // 카테고리가 지정된 경우, 조건을 추가
            if (category != null && !category.isEmpty()) {
                pstmt.setString(paramIndex++, category);
            }
            pstmt.setInt(paramIndex++, offset);
            pstmt.setInt(paramIndex, limit);
            
            ResultSet rs = pstmt.executeQuery();
            // 결과 집합을 DTO 객체로 변환하여 리스트에 추가
            while (rs.next()) {
                products.add(createProductFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 상품 목록 리스트 반환
        return products;
    }
    
    /**
     * 상품 총 개수 조회
     */
    public int getTotalProductCount(String category) {
        // 기본 SQL 쿼리 작성
        String sql = "SELECT COUNT(*) FROM product";
        
        // 카테고리가 지정된 경우, 조건을 추가
        if (category != null && !category.isEmpty()) {
            sql += " WHERE category = ?";
        }
        
        // DB 연결 및 SQL 실행을 위한 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
        // 카테고리가 지정된 경우, 조건을 추가
            if (category != null && !category.isEmpty()) {
                pstmt.setString(1, category);
            }
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * 상품 상세 조회
     */
    public ProductDTO getProductById(int productId) {
        // 기본 SQL 쿼리 작성
        String sql = "SELECT * FROM product WHERE id = ?";
        
        // DB 연결 및 SQL 실행을 위한 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return createProductFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * 상품 검색 (상품명으로 검색)
     */
    public List<ProductDTO> searchProducts(String keyword, int offset, int limit) {
        // 결과를 저장할 리스트 초기화
        List<ProductDTO> products = new ArrayList<>();
        // 기본 SQL 쿼리 작성
        String sql = "SELECT * FROM product WHERE name LIKE ? ORDER BY id DESC LIMIT ?, ?";
        
        // DB 연결 및 SQL 실행을 위한 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, "%" + keyword + "%");
            pstmt.setInt(2, offset);
            pstmt.setInt(3, limit);
            
            ResultSet rs = pstmt.executeQuery();
            // 결과 집합을 DTO 객체로 변환하여 리스트에 추가
            while (rs.next()) {
                products.add(createProductFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 상품 목록 리스트 반환
        return products;
    }
    
    /**
     * 검색 결과 총 개수 조회
     */
    public int getSearchResultCount(String keyword) {
        // 기본 SQL 쿼리 작성
        String sql = "SELECT COUNT(*) FROM product WHERE name LIKE ?";
        
        // DB 연결 및 SQL 실행을 위한 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, "%" + keyword + "%");
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * 카테고리 목록 조회 (중복 제거)
     */
    public List<String> getCategories() {
        List<String> categories = new ArrayList<>();
        // 기본 SQL 쿼리 작성
        String sql = "SELECT DISTINCT category FROM product ORDER BY category";
        
        // DB 연결 및 SQL 실행을 위한 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = pstmt.executeQuery();
            // 결과 집합을 DTO 객체로 변환하여 리스트에 추가
            while (rs.next()) {
                categories.add(rs.getString("category"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categories;
    }
    
    /**
     * 여러 상품 ID로 상품 정보 조회 (장바구니용)
     */
    public List<ProductDTO> getProductsByIds(List<Integer> productIds) {
        if (productIds == null || productIds.isEmpty()) {
            return new ArrayList<>();
        }
        
        // 결과를 저장할 리스트 초기화
        List<ProductDTO> products = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM product WHERE id IN (");
        
        for (int i = 0; i < productIds.size(); i++) {
            sql.append("?");
            if (i < productIds.size() - 1) {
                sql.append(",");
            }
        }
        sql.append(")");
        
        // DB 연결 및 SQL 실행을 위한 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < productIds.size(); i++) {
                pstmt.setInt(i + 1, productIds.get(i));
            }
            
            ResultSet rs = pstmt.executeQuery();
            // 결과 집합을 DTO 객체로 변환하여 리스트에 추가
            while (rs.next()) {
                products.add(createProductFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 상품 목록 리스트 반환
        return products;
    }
    
    /**
     * ResultSet으로부터 ProductDTO 객체 생성
     */
    private ProductDTO createProductFromResultSet(ResultSet rs) throws SQLException {
        ProductDTO product = new ProductDTO();
        product.setId(rs.getInt("id"));
        product.setName(rs.getString("name"));
        product.setManufacturer(rs.getString("manufacturer"));
        product.setCategory(rs.getString("category"));
        product.setPrice(rs.getInt("price"));
        product.setStock(rs.getInt("stock"));
        product.setImageUrl(rs.getString("imageUrl"));
        product.setDescription(rs.getString("description"));
        return product;
    }
}