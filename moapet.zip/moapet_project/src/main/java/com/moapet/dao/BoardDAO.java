// 현재 클래스의 패키지 선언
package com.moapet.dao;

// 필요한 클래스 및 유틸리티 임포트
import com.moapet.dto.BoardDTO;
import com.moapet.dto.BoardFileDTO;
import com.moapet.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 게시판 관련 데이터베이스 접근 클래스
 */
// 게시판 관련 데이터 처리를 담당하는 DAO 클래스
public class BoardDAO {
    
    /**
     * 게시글 목록 조회 (페이징)
     */
    // 특정 게시판 타입의 게시글을 페이징하여 조회
    public List<BoardDTO> getBoardList(String boardType, int offset, int limit) {
        // 결과를 저장할 리스트 초기화
        List<BoardDTO> list = new ArrayList<>();
        // 기본 SQL 쿼리문
        String sql = "SELECT * FROM board";
        
        if (boardType != null && !boardType.isEmpty()) {
            sql += " WHERE board_type = ?";
        }
        sql += " ORDER BY id DESC LIMIT ?, ?";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            int paramIndex = 1;
            if (boardType != null && !boardType.isEmpty()) {
                pstmt.setString(paramIndex++, boardType);
            }
            pstmt.setInt(paramIndex++, offset);
            pstmt.setInt(paramIndex, limit);
            
            ResultSet rs = pstmt.executeQuery();
            // 결과 집합을 순회하며 DTO 객체로 변환
            while (rs.next()) {
                list.add(createBoardFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 결과 리스트 반환
        return list;
    }
    
    /**
     * 게시글 총 개수 조회
     */
    public int getTotalCount(String boardType) {
        // 기본 SQL 쿼리문
        String sql = "SELECT COUNT(*) FROM board";
        
        if (boardType != null && !boardType.isEmpty()) {
            sql += " WHERE board_type = ?";
        }
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            if (boardType != null && !boardType.isEmpty()) {
                pstmt.setString(1, boardType);
            }
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * 게시글 상세 조회
     */
    public BoardDTO getBoardDetail(int id) {
        // 기본 SQL 쿼리문
        String sql = "SELECT * FROM board WHERE id = ?";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return createBoardFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * 게시글 조회수 증가
     */
    public void increaseHit(int id) {
        String sql = "UPDATE board SET hit = hit + 1 WHERE id = ?";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * 게시글 작성
     */
    public int insertBoard(BoardDTO board) {
        String sql = "INSERT INTO board (board_type, title, content, region, writer) VALUES (?, ?, ?, ?, ?)";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, board.getBoardType());
            pstmt.setString(2, board.getTitle());
            pstmt.setString(3, board.getContent());
            pstmt.setString(4, board.getRegion());
            pstmt.setString(5, board.getWriter());
            
            int result = pstmt.executeUpdate();
            
            if (result > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    return rs.getInt(1); // 생성된 게시글 ID 반환
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    /**
     * 게시글 수정
     */
    public boolean updateBoard(BoardDTO board) {
        String sql = "UPDATE board SET title = ?, content = ?, region = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ? AND writer = ?";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, board.getTitle());
            pstmt.setString(2, board.getContent());
            pstmt.setString(3, board.getRegion());
            pstmt.setInt(4, board.getId());
            pstmt.setString(5, board.getWriter());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 게시글 삭제
     */
    public boolean deleteBoard(int id, String writer) {
        String sql = "DELETE FROM board WHERE id = ? AND writer = ?";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, id);
            pstmt.setString(2, writer);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 특정 회원이 작성한 게시글 목록 조회
     */
    // 특정 게시판 타입의 게시글을 페이징하여 조회
    public List<BoardDTO> getBoardListByWriter(String writer) {
        // 결과를 저장할 리스트 초기화
        List<BoardDTO> list = new ArrayList<>();
        // 기본 SQL 쿼리문
        String sql = "SELECT * FROM board WHERE writer = ? ORDER BY id DESC";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, writer);
            ResultSet rs = pstmt.executeQuery();
            
            // 결과 집합을 순회하며 DTO 객체로 변환
            while (rs.next()) {
                list.add(createBoardFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 결과 리스트 반환
        return list;
    }
    
    /**
     * 게시글 파일 정보 저장
     */
    public boolean insertBoardFile(BoardFileDTO file) {
        String sql = "INSERT INTO board_file (board_id, original_name, stored_name, file_type) VALUES (?, ?, ?, ?)";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, file.getBoardId());
            pstmt.setString(2, file.getOriginalName());
            pstmt.setString(3, file.getStoredName());
            pstmt.setString(4, file.getFileType());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 게시글의 파일 목록 조회
     */
    public List<BoardFileDTO> getBoardFiles(int boardId) {
        List<BoardFileDTO> files = new ArrayList<>();
        // 기본 SQL 쿼리문
        String sql = "SELECT * FROM board_file WHERE board_id = ? ORDER BY id";
        
        // 데이터베이스 연결 및 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, boardId);
            ResultSet rs = pstmt.executeQuery();
            
            // 결과 집합을 순회하며 DTO 객체로 변환
            while (rs.next()) {
                BoardFileDTO file = new BoardFileDTO();
                file.setId(rs.getInt("id"));
                file.setBoardId(rs.getInt("board_id"));
                file.setOriginalName(rs.getString("original_name"));
                file.setStoredName(rs.getString("stored_name"));
                file.setFileType(rs.getString("file_type"));
                file.setUploadedAt(rs.getTimestamp("uploaded_at"));
                files.add(file);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return files;
    }
    
    /**
     * ResultSet으로부터 BoardDTO 객체 생성
     */
    private BoardDTO createBoardFromResultSet(ResultSet rs) throws SQLException {
        BoardDTO board = new BoardDTO();
        board.setId(rs.getInt("id"));
        board.setBoardType(rs.getString("board_type"));
        board.setTitle(rs.getString("title"));
        board.setContent(rs.getString("content"));
        board.setRegion(rs.getString("region"));
        board.setWriter(rs.getString("writer"));
        board.setHit(rs.getInt("hit"));
        board.setCreatedAt(rs.getTimestamp("created_at"));
        board.setUpdatedAt(rs.getTimestamp("updated_at"));
        return board;
    }
}