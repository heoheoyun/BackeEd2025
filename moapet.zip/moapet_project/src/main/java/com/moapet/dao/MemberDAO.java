// 현재 클래스의 패키지 선언
package com.moapet.dao;

// DTO, DB 유틸, JDBC 관련 클래스 임포트
import com.moapet.dto.MemberDTO;
import com.moapet.util.DBUtil;
import java.sql.*;


/**
 * 회원 관련 데이터베이스 접근 클래스
 */
// 회원 관련 데이터 처리용 DAO 클래스
public class MemberDAO {
    
    /**
     * 회원 로그인 - 아이디/비밀번호 확인
     */
    // 회원 로그인 검증: 아이디, 비밀번호, 상태 확인
    public MemberDTO login(String memberId, String password) {
        // 로그인 SQL 쿼리: 활성 상태 회원만 조회
        String sql = "SELECT * FROM member WHERE member_id = ? AND password = ? AND status = 'A'";
        
        // DB 연결 및 쿼리 실행 (try-with-resources 사용)
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // SQL 파라미터 설정
            pstmt.setString(1, memberId);
            // SQL 파라미터 설정
            pstmt.setString(2, password);
            
            ResultSet rs = pstmt.executeQuery();
                // 조회 결과가 있으면 MemberDTO로 변환
            if (rs.next()) {
                return createMemberFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 일치하는 회원 정보가 없으면 null 반환
        return null;
    }
    
    /**
     * 회원가입 - 새 회원 등록
     */
    public boolean register(MemberDTO member) {
        String sql = "INSERT INTO member (member_id, password, name, phone, zipcode, address, detail_address, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'A')";
        
        // DB 연결 및 쿼리 실행 (try-with-resources 사용)
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // SQL 파라미터 설정
            pstmt.setString(1, member.getMemberId());
            // SQL 파라미터 설정
            pstmt.setString(2, member.getPassword());
            // SQL 파라미터 설정
            pstmt.setString(3, member.getName());
            // SQL 파라미터 설정
            pstmt.setString(4, member.getPhone());
            // SQL 파라미터 설정
            pstmt.setString(5, member.getZipcode());
            // SQL 파라미터 설정
            pstmt.setString(6, member.getAddress());
            // SQL 파라미터 설정
            pstmt.setString(7, member.getDetailAddress());
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 아이디 중복 확인
     */
    public boolean checkDuplicateId(String memberId) {
        // 로그인 SQL 쿼리: 활성 상태 회원만 조회
        String sql = "SELECT COUNT(*) FROM member WHERE member_id = ?";
        
        // DB 연결 및 쿼리 실행 (try-with-resources 사용)
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // SQL 파라미터 설정
            pstmt.setString(1, memberId);
            ResultSet rs = pstmt.executeQuery();
            
                // 조회 결과가 있으면 MemberDTO로 변환
            if (rs.next()) {
                return rs.getInt(1) > 0; // 존재하면 true (중복)
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 회원 정보 조회
     */
    public MemberDTO getMemberById(String memberId) {
        // 로그인 SQL 쿼리: 활성 상태 회원만 조회
        String sql = "SELECT * FROM member WHERE member_id = ? AND status = 'A'";
        
        // DB 연결 및 쿼리 실행 (try-with-resources 사용)
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // SQL 파라미터 설정
            pstmt.setString(1, memberId);
            ResultSet rs = pstmt.executeQuery();
            
                // 조회 결과가 있으면 MemberDTO로 변환
            if (rs.next()) {
                return createMemberFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 일치하는 회원 정보가 없으면 null 반환
        return null;
    }
    
    /**
     * ResultSet으로부터 MemberDTO 객체 생성
     */
    private MemberDTO createMemberFromResultSet(ResultSet rs) throws SQLException {
        MemberDTO member = new MemberDTO();
        member.setMemberId(rs.getString("member_id"));
        member.setPassword(rs.getString("password"));
        member.setName(rs.getString("name"));
        member.setPhone(rs.getString("phone"));
        member.setZipcode(rs.getString("zipcode"));
        member.setAddress(rs.getString("address"));
        member.setDetailAddress(rs.getString("detail_address"));
        member.setStatus(rs.getString("status"));
        return member;
    }
}