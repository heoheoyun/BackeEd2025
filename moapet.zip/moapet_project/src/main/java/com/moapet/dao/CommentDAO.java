// 현재 클래스의 패키지 선언
package com.moapet.dao;

// 필요한 DTO, 유틸리티, SQL 및 리스트 관련 클래스 임포트
import com.moapet.dto.CommentDTO;
import com.moapet.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 댓글 관련 데이터베이스 접근 클래스
 */
// 댓글 관련 데이터베이스 처리를 담당하는 DAO 클래스
public class CommentDAO {
    
    /**
     * 특정 게시글의 댓글 목록 조회
     */
    // 게시글 ID를 기반으로 해당 게시글의 댓글 목록 조회
    public List<CommentDTO> getCommentsByBoardId(int boardId) {
        // 결과를 저장할 리스트 생성
        List<CommentDTO> comments = new ArrayList<>();
        // 댓글 조회 SQL 쿼리 (작성 순으로 정렬)
        String sql = "SELECT * FROM comment WHERE board_id = ? ORDER BY id ASC";
        
        // 데이터베이스 연결 설정 및 쿼리 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, boardId);
            ResultSet rs = pstmt.executeQuery();
            
            // 조회 결과를 DTO로 변환하여 리스트에 추가
            while (rs.next()) {
                comments.add(createCommentFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 댓글 리스트 반환
        return comments;
    }
    
    /**
     * 댓글 작성
     */
    public boolean insertComment(CommentDTO comment) {
        // 댓글 조회 SQL 쿼리 (작성 순으로 정렬)
        String sql = "INSERT INTO comment (board_id, writer, content, parent_id) VALUES (?, ?, ?, ?)";
        
        // 데이터베이스 연결 설정 및 쿼리 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, comment.getBoardId());
            pstmt.setString(2, comment.getWriter());
            pstmt.setString(3, comment.getContent());
            
            if (comment.getParentId() != null) {
                pstmt.setInt(4, comment.getParentId());
            } else {
                pstmt.setNull(4, Types.INTEGER);
            }
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 댓글 수정
     */
    public boolean updateComment(int commentId, String content, String writer) {
        // 댓글 조회 SQL 쿼리 (작성 순으로 정렬)
        String sql = "UPDATE comment SET content = ? WHERE id = ? AND writer = ?";
        
        // 데이터베이스 연결 설정 및 쿼리 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, content);
            pstmt.setInt(2, commentId);
            pstmt.setString(3, writer);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 댓글 삭제
     */
    public boolean deleteComment(int commentId, String writer) {
        // 댓글 조회 SQL 쿼리 (작성 순으로 정렬)
        String sql = "DELETE FROM comment WHERE id = ? AND writer = ?";
        
        // 데이터베이스 연결 설정 및 쿼리 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, commentId);
            pstmt.setString(2, writer);
            
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    /**
     * 특정 회원이 작성한 댓글 목록 조회
     */
    public List<CommentDTO> getCommentsByWriter(String writer) {
        // 결과를 저장할 리스트 생성
        List<CommentDTO> comments = new ArrayList<>();
        // 댓글 조회 SQL 쿼리 (작성 순으로 정렬)
        String sql = "SELECT * FROM comment WHERE writer = ? ORDER BY id DESC";
        
        // 데이터베이스 연결 설정 및 쿼리 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, writer);
            ResultSet rs = pstmt.executeQuery();
            
            // 조회 결과를 DTO로 변환하여 리스트에 추가
            while (rs.next()) {
                comments.add(createCommentFromResultSet(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        // 댓글 리스트 반환
        return comments;
    }
    
    /**
     * 댓글 상세 조회 (수정/삭제 권한 확인용)
     */
    public CommentDTO getCommentById(int commentId) {
        // 댓글 조회 SQL 쿼리 (작성 순으로 정렬)
        String sql = "SELECT * FROM comment WHERE id = ?";
        
        // 데이터베이스 연결 설정 및 쿼리 실행 준비
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, commentId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return createCommentFromResultSet(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    /**
     * ResultSet으로부터 CommentDTO 객체 생성
     */
    private CommentDTO createCommentFromResultSet(ResultSet rs) throws SQLException {
        CommentDTO comment = new CommentDTO();
        comment.setId(rs.getInt("id"));
        comment.setBoardId(rs.getInt("board_id"));
        comment.setWriter(rs.getString("writer"));
        comment.setContent(rs.getString("content"));
        
        int parentId = rs.getInt("parent_id");
        if (!rs.wasNull()) {
            comment.setParentId(parentId);
        }
        
        comment.setCreatedAt(rs.getTimestamp("created_at"));
        return comment;
    }
}