package cs.dit.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;

public class MemberUpdateService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		int bcode      = Integer.parseInt(request.getParameter("bcode"));
        String subject = request.getParameter("subject");
        String content = request.getParameter("content");
        String writer  = request.getParameter("writer");

        MemberDTO dto = new MemberDTO();
        dto.setBcode(bcode);
        dto.setSubject(subject);
        dto.setContent(content);
        dto.setWriter(writer);

        MemberDAO dao = new MemberDAO();
        dao.update(dto);

	}

}
